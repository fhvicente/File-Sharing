from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox

import random as rd


class Exercicio35b(GridLayout):
    """ Exercicio 35 - b - """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.cols = 3
        self.row_force_default = True
        self.row_default_height = 40
        self.spacing = 10
        self.padding = 40

        self.textbox1 = TextInput(text="",
                                  multiline=False)
        self.add_widget(self.textbox1)
        self.textbox2 = TextInput(text="",
                                  multiline=False)
        self.add_widget(self.textbox2)
        self.textbox1.bind(text=self.texto_invertido)

    def texto_invertido(self, instance, text):
        # Imprime na consola
        print("Texto > ", self.textbox1.text)
        # Altera o texto da caixa 2 para o texto invertido da caixa 1
        self.textbox2.text = text[::-1]


class Exercicio35c(GridLayout):
    """ Exercicio 35 - c - """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.cols = 3
        self.row_force_default = True
        self.row_default_height = 40
        self.spacing = 10
        self.padding = 40

        self.textbox1 = TextInput(text="Digite um texto",
                                  multiline=False)
        self.add_widget(self.textbox1)
        self.textbox1.bind(text=self.compara_textos)
        self.textbox2 = TextInput(text="Digite um texto",
                                  multiline=False)
        self.add_widget(self.textbox2)
        self.textbox2.bind(text=self.compara_textos)

        box = BoxLayout(orientation='horizontal')
        self.label1 = Label(text="",
                            font_size="20sp")
        box.add_widget(self.label1)
        self.add_widget(box)

    def compara_textos(self, instance, text):
        if self.textbox1.text == text[::-1]:
            msg = "Textos Inversos"
            self.label1.color = 1, 0, 0, 1
            self.label1.text = msg
        # elif self.textbox1.text != self.textbox2.text:
        #    msg = "Textos Diferentes"
        #    self.label1.color = 0, 1, 0, 1
        #    self.label1.text = msg
        else:
            msg = "Textos Não Inversos"
            self.label1.color = 0, 1, 0, 1
            self.label1.text = msg


class Exercicio35e(GridLayout):
    """ Exercicio 35 - e - """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.cols = 3
        self.row_force_default = True
        self.row_default_height = 40
        self.spacing = 10
        self.padding = 40

        self.textbox1 = TextInput(text="Texto 1")
        self.add_widget(self.textbox1)
        self.textbox2 = TextInput(text="Texto 2")
        self.add_widget(self.textbox2)
        submit = Button(text="Trocar de Caixa",
                        on_press=self.troca_texto)
        self.add_widget(submit)

    def troca_texto(self, instance):
        text = self.textbox2.text
        self.textbox2.text = self.textbox1.text
        self.textbox1.text = text


class Exercicio35i(GridLayout):
    """ Exercicio 35 - i - """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.counter = 0

        self.cols = 3
        self.row_force_default = True
        self.row_default_height = 40
        self.spacing = 10
        self.padding = 40

        box = BoxLayout(orientation='horizontal')
        self.check_box_label = Label(text="A CheckBox")
        box.add_widget(self.check_box_label)
        self.check_box = CheckBox(active=True)
        box.add_widget(self.check_box)
        self.add_widget(box)

        submit = Button(text="Contador",
                        on_press=self.conta_true_false)
        self.add_widget(submit)

        self.textbox1 = TextInput(text="Display",
                                  halign="center",
                                  font_size="25sp")
        self.add_widget(self.textbox1)

    def conta_true_false(self, instance):
        if self.check_box.active:
            self.counter += 1
        else:
            self.counter -= 1

        self.textbox1.text = str(self.counter)
        print(self.counter)


class Exercicio35k(GridLayout):
    """ Exercicio 35 - k - """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.counter = 1
        self.numero_aleatorio = str(rd.randint(1, 100))

        self.cols = 1
        self.row_force_default = True
        self.row_default_height = 40
        self.spacing = 10
        self.padding = 40

        box1 = BoxLayout(orientation='vertical')
        self.add_widget(box1)
        self.label1 = Label(text="Jogo da Adivinha",
                            font_size="25sp")
        box1.add_widget(self.label1)

        box2 = BoxLayout(orientation='horizontal')
        self.add_widget(box2)
        self.textbox1 = TextInput(hint_text="Tente adivinhar o número",
                                  halign="center",
                                  font_size="20sp",
                                  multiline=False)
        box2.add_widget(self.textbox1)
        self.textbox2 = TextInput(password=True,
                                  halign="center",
                                  font_size="20sp",
                                  multiline=False)
        self.textbox2.text = self.numero_aleatorio
        print(self.numero_aleatorio)
        box2.add_widget(self.textbox2)

        submit = Button(text="Boa Sorte",
                        on_press=self.verifica_random_number)
        self.add_widget(submit)

        box3 = BoxLayout(orientation='horizontal')
        self.label2 = Label(text="",
                            font_size="20sp")
        box3.add_widget(self.label2)
        self.add_widget(box3)

        box4 = BoxLayout(orientation='horizontal')
        self.label3 = Label(text="",
                            font_size="20sp")
        box4.add_widget(self.label3)
        self.add_widget(box4)

    def verifica_random_number(self, instance):
        if int(self.textbox1.text) > int(self.textbox2.text):
            self.label2.color = 1, 0, 0, 1
            self.label2.text = "Tenta um número menor"
            self.counter += 1
        elif int(self.textbox1.text) < int(self.textbox2.text):
            self.label2.color = 0, 1, 0, 1
            self.label2.text = "Tenta um número maior"
            self.counter += 1
        else:
            self.label2.text = "Acertaste"
            self.label3.color = 0, 1, 0, 1
            self.label3.text = "Foram feitas " + str(self.counter) + " tentavias para acertar"
            self.textbox2.password = False


class MyApp(App):
    def build(self):
        return Exercicio35b()
        # return Exercicio35c()
        # return Exercicio35e()
        # return Exercicio35i()
        # return Exercicio35k()


if __name__ == '__main__':
    MyApp().run()

